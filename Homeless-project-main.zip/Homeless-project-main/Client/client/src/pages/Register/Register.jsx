import React from "react";
import RegisterForm from "../../components/Log/RegisterForm/RegisterForm";

const Register = () => {
  return <RegisterForm />;
};

export default Register;
