import React from "react";
import LoginForm from "../../components/Log/LoginForm/LoginForm";
const Login = () => {
  return <LoginForm />;
};

export default Login;
