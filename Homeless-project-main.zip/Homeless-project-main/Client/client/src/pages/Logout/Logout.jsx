import React from "react";
import LogoutUser from "../../components/Log/LogoutUser/LogoutUser";

const Logout = () => {
  return <LogoutUser />;
};

export default Logout;
